﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb1SQL.Funktioner
{
    internal class BetygRelaterat
    {
        public static void HämtaAllaBetygFrånSenasteMånaden(SqlDataReader reader)
        {

            string förnamn = reader.GetString(0);
            string Efternamn = reader.GetString(1);
            string KursNamn = reader.GetString(2);
            int Betygssiffra = reader.GetInt32(3);
            string Månad = reader.GetString(4);
            Console.WriteLine($"Förnamn: {förnamn}, Efternamn: {Efternamn}, Kursnamn: {KursNamn}, Betygssiffra: {Betygssiffra}, Månad: {Månad}");
        }

        public static void SnittbetygPerKurs(SqlDataReader reader)
        {
            string kursnamn = reader.GetString(1);
            int snittbetyg = reader.GetInt32(2);
            int högstaBetyg = reader.GetInt32(3);
            int lägstaBetyg = reader.GetInt32(4);

            Console.WriteLine($"Kurs: {kursnamn}, Snittbetyg: {snittbetyg}, Högsta betyg: {högstaBetyg}, Lägsta betyg: {lägstaBetyg}");
        }
    }
}

