﻿using Microsoft.Data.SqlClient;
using System;

namespace Labb1SQL.Funktioner
{
    internal class ElevRelaterat
    {
        public static void StudentRelateradeProcesser(SqlDataReader reader)
        {
            int elevID = reader.GetInt32(0);
            string förnamn = reader.GetString(1);
            string Efternamn = reader.GetString(2);
            int Ålder = reader.GetInt32(3);
            string AnnanRelevantInfo = reader.GetString(4);
            int KlassID = reader.GetInt32(5);
            Console.WriteLine($"ElevID: {elevID}, Förnamn: {förnamn}, Efternamn: {Efternamn}, Ålder {Ålder}, AnnanRelevantInfo: {AnnanRelevantInfo}, KlassID {KlassID}");
        }

        public static void LäggTillElev(SqlConnection connection)
        {
            Console.WriteLine("Förnamn?");
            string ElevFörnamn = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Efternamn?");
            string ElevEfternamn = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Ålder?");
            string ElevÅlder = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("ÖvrigInformation?");
            string ElevAnnanRelevantInfo = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("KlassID? (1-3)");
            string inputKlassID = Console.ReadLine();
            Console.WriteLine();

            int KlassID;

            if (int.TryParse(inputKlassID, out int IntKlassID) && IntKlassID >= 1 && IntKlassID <= 3)
            {
                KlassID = IntKlassID;
                string sqlQuery = $"INSERT INTO Elever (Förnamn, Efternamn, Ålder, AnnanRelevantInfo, KlassID) VALUES ('{ElevFörnamn}', '{ElevEfternamn}', '{ElevÅlder}', '{ElevAnnanRelevantInfo}', {KlassID});";
                Program.ExecuteAndDisplayQuery(connection, sqlQuery, null);
            }
            else
            {

                Console.WriteLine("Felaktig input. Ange ett giltigt nummer mellan 1 och 3.");

            }
        }
    }
}