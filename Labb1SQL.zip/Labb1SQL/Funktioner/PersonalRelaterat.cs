﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb1SQL.Funktioner
{
    internal class PersonalRelaterat
    {
        public static void HämtaPersonal(SqlDataReader reader)
        {
            int PersonalID = reader.GetInt32(0);
            string förnamn = reader.GetString(1);
            string Efternamn = reader.GetString(2);
            string Kategori = reader.GetString(3);
            Console.WriteLine($"PersonalID: {PersonalID}, Förnamn: {förnamn}, Efternamn: {Efternamn}, Kategori {Kategori}");
        }


        public static void LäggTillPersonal(SqlConnection connection)
        {
            Console.WriteLine("Förnamn?");
            string PersonalFörnamn = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Efternamn?");
            string PersonalEfternamn = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Kategori?");
            string PersonalKategori = Console.ReadLine();
            Console.WriteLine();

            string sqlQuery = $"INSERT INTO Personal (Förnamn, Efternamn, Kategori) VALUES ('{PersonalFörnamn}', '{PersonalEfternamn}', '{PersonalKategori}');";

            Program.ExecuteAndDisplayQuery(connection, sqlQuery, null);
        }

    }
}

