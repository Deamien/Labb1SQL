﻿using Azure;
using Microsoft.Data.SqlClient;
using System;
using System.Runtime.ConstrainedExecution;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Labb1SQL
{
    class Program
    {
        static void Main()
        {
            string connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Labb1SQL;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                while (true)
                {
                    Program program = new Program();
                    program.Huvudmeny();
                    string val = Console.ReadLine();
                    Console.WriteLine();
                    switch (val)
                    {
                        case "1":
                            Program.ExecuteAndDisplayQuery(connection, $"SELECT * FROM Elever", Program.StudentRelateradeProcesser);
                            break;
                        case "2":
                            Console.WriteLine("Vilken Klass?");
                            string klassval = Console.ReadLine();
                            Console.WriteLine();
                            Program.ExecuteAndDisplayQuery(connection, $"SELECT Elever.* FROM Elever JOIN Klasser ON " +
                                $"Elever.KlassID = Klasser.KlassID WHERE Klasser.KlassID = '{klassval}'", Program.StudentRelateradeProcesser);
                            break;
                        case "3":
                            LäggTillPersonal(connection);
                            break;
                        case "4":
                            Program.ExecuteAndDisplayQuery(connection, $"SELECT * FROM Personal", Program.HämtaPersonal);
                            break;
                        case "5":
                            Program.ExecuteAndDisplayQuery(connection,$"SELECT Elever.Förnamn, Elever.Efternamn, Kurser.Kursnamn, " +
                                $"Betyg.Betygssiffra, Betyg.Månad FROM Betyg JOIN Elever ON Betyg.ElevID = Elever.ElevID JOIN Kurser ON " +
                                $"Betyg.KursID = Kurser.KursID WHERE Betyg.Månad = 'dec';", Program.HämtaAllaBetygFrånSenasteMånaden);
                            break;
                        case "6":
                            Program.ExecuteAndDisplayQuery(connection,$"SELECT Kurser.KursID, Kurser.Kursnamn, AVG(Betyg.Betygssiffra) " +
                                $"AS Snittbetyg, MAX(Betyg.Betygssiffra) AS HögstaBetyg, MIN(Betyg.Betygssiffra) AS LägstaBetyg FROM " +
                                $"Kurser LEFT JOIN Betyg ON Kurser.KursID = Betyg.KursID GROUP BY Kurser.KursID, Kurser.Kursnamn;", Program.SnittbetygPerKurs);
                            break;
                        case "7":
                            LäggTillElev(connection);
                            break;
                        case "8":
                            Console.WriteLine("Programmet avslutas.");
                            return;
                        default:
                            Console.WriteLine("Ogiltigt val. Försök igen.");
                            Console.WriteLine();
                            break;
                    }
                    Console.WriteLine();
                    Console.WriteLine("Tryck Valfri Knapp För Att Fortsätta");
                    Console.ReadLine();
                }
            }
        }

        static void ExecuteAndDisplayQuery(SqlConnection connection, string sqlQuery, Action<SqlDataReader> HämtaDatan)
        {
            using (SqlCommand command = new SqlCommand(sqlQuery, connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        HämtaDatan(reader);
                    }
                }
            }
        }

        static void StudentRelateradeProcesser(SqlDataReader reader)
        {
            int elevID = reader.GetInt32(0);
            string förnamn = reader.GetString(1);
            string Efternamn = reader.GetString(2);
            int Ålder = reader.GetInt32(3);
            string AnnanRelevantInfo = reader.GetString(4);
            int KlassID = reader.GetInt32(5);
            Console.WriteLine($"ElevID: {elevID}, Förnamn: {förnamn}, Efternamn: {Efternamn}, Ålder {Ålder}, AnnanRelevantInfo: {AnnanRelevantInfo}, KlassID {KlassID}");
        }

        static void HämtaPersonal(SqlDataReader reader)
        {
            int PersonalID = reader.GetInt32(0);
            string förnamn = reader.GetString(1);
            string Efternamn = reader.GetString(2);
            string Kategori = reader.GetString(3);
            Console.WriteLine($"PersonalID: {PersonalID}, Förnamn: {förnamn}, Efternamn: {Efternamn}, Kategori {Kategori}");
        }

        static void LäggTillPersonal(SqlConnection connection)
        {
            Console.WriteLine("Förnamn?");
            string PersonalFörnamn = Console.ReadLine();
            Console.WriteLine();
            
            Console.WriteLine("Efternamn?");
            string PersonalEfternamn = Console.ReadLine();
            Console.WriteLine();
           
            Console.WriteLine("Kategori?");
            string PersonalKategori = Console.ReadLine();
            Console.WriteLine();
            
            string sqlQuery= ($"INSERT INTO Personal (Förnamn, Efternamn, Kategori) VALUES ('{PersonalFörnamn}', '{PersonalEfternamn}', '{PersonalKategori}');");

            ExecuteAndDisplayQuery(connection, sqlQuery, null);
        }

        static void HämtaAllaBetygFrånSenasteMånaden(SqlDataReader reader)
        {

            string förnamn = reader.GetString(0);
            string Efternamn = reader.GetString(1);
            string KursNamn = reader.GetString(2);
            int Betygssiffra = reader.GetInt32(3);
            String Månad = reader.  GetString(4);
            Console.WriteLine($"Förnamn: {förnamn}, Efternamn: {Efternamn}, Kursnamn: {KursNamn}, Betygssiffra: {Betygssiffra}, Månad: {Månad}");
        }

        static void SnittbetygPerKurs(SqlDataReader reader)
        {
            string kursnamn = reader.GetString(1);
            int snittbetyg = reader.GetInt32(2);
            int högstaBetyg = reader.GetInt32(3);
            int lägstaBetyg = reader.GetInt32(4);

            Console.WriteLine($"Kurs: {kursnamn}, Snittbetyg: {snittbetyg}, Högsta betyg: {högstaBetyg}, Lägsta betyg: {lägstaBetyg}");
        }

        static void LäggTillElev(SqlConnection connection)
        {
            Console.WriteLine("Förnamn?");
            string ElevFörnamn = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Efternamn?");
            string ElevEfternamn = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Ålder?");
            string ElevÅlder = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("ÖvrigInformation?");
            string ElevAnnanRelevantInfo = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("KlassID? (1-3)");
            string inputKlassID = Console.ReadLine();
            Console.WriteLine();

            int KlassID;

            if (int.TryParse(inputKlassID, out int IntKlassID) && IntKlassID >= 1 && IntKlassID <= 3)
            {
                KlassID = IntKlassID;
                string sqlQuery = ($"INSERT INTO Elever (Förnamn, Efternamn, Ålder, AnnanRelevantInfo, KlassID) VALUES ('{ElevFörnamn}', '{ElevEfternamn}', '{ElevÅlder}', '{ElevAnnanRelevantInfo}', {KlassID});");
                ExecuteAndDisplayQuery(connection, sqlQuery, null);
            }
            else
            {

                Console.WriteLine("Felaktig input. Ange ett giltigt nummer mellan 1 och 3.");
            
            }
            
        }

        void Huvudmeny()
        {
            Console.WriteLine();
            Console.WriteLine("Välkommen till huvudmenyn!");
            Console.WriteLine("1. Hämta alla elever");
            Console.WriteLine("2. Hämta alla elever i en viss klass");
            Console.WriteLine("3. Lägg till ny personal");
            Console.WriteLine("4. Hämta personal");
            Console.WriteLine("5. Hämta alla betyg från senaste månaden");
            Console.WriteLine("6. Snittbetyg per kurs");
            Console.WriteLine("7. Lägg till nya elever");
            Console.WriteLine("8. Avsluta programmet");
            Console.WriteLine();
            Console.Write("Vänligen välj en funktion genom att mata in en siffra: ");
            Console.WriteLine();
        }
    }
}
