﻿using Azure;
using Labb1SQL.Funktioner;
using Microsoft.Data.SqlClient;
using System;
using System.Runtime.ConstrainedExecution;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Labb1SQL
{
    class Program
    {
        static void Main()
        {
            string connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Labb1SQL;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                while (true)
                {
                    Program program = new Program();
                    program.Huvudmeny();
                    string val = Console.ReadLine();
                    Console.WriteLine();
                    switch (val)
                    {
                        case "1":
                            ExecuteAndDisplayQuery(connection, $"SELECT * FROM Elever", ElevRelaterat.StudentRelateradeProcesser);
                            break;
                        case "2":
                            Console.WriteLine("Vilken Klass?");
                            string klassval = Console.ReadLine();
                            Console.WriteLine();
                            ExecuteAndDisplayQuery(connection, $"SELECT Elever.* FROM Elever JOIN Klasser ON " +
                                $"Elever.KlassID = Klasser.KlassID WHERE Klasser.KlassID = '{klassval}'", ElevRelaterat.StudentRelateradeProcesser);
                            break;
                        case "3":
                            PersonalRelaterat.LäggTillPersonal(connection);
                            break;
                        case "4":
                            ExecuteAndDisplayQuery(connection, $"SELECT * FROM Personal", PersonalRelaterat.HämtaPersonal);
                            break;
                        case "5":
                            ExecuteAndDisplayQuery(connection,$"SELECT Elever.Förnamn, Elever.Efternamn, Kurser.Kursnamn, " +
                                $"Betyg.Betygssiffra, Betyg.Månad FROM Betyg JOIN Elever ON Betyg.ElevID = Elever.ElevID JOIN Kurser ON " +
                                $"Betyg.KursID = Kurser.KursID WHERE Betyg.Månad = 'dec';", BetygRelaterat.HämtaAllaBetygFrånSenasteMånaden);
                            break;
                        case "6":
                            ExecuteAndDisplayQuery(connection,$"SELECT Kurser.KursID, Kurser.Kursnamn, AVG(Betyg.Betygssiffra) " +
                                $"AS Snittbetyg, MAX(Betyg.Betygssiffra) AS HögstaBetyg, MIN(Betyg.Betygssiffra) AS LägstaBetyg FROM " +
                                $"Kurser LEFT JOIN Betyg ON Kurser.KursID = Betyg.KursID GROUP BY Kurser.KursID, Kurser.Kursnamn;", BetygRelaterat.SnittbetygPerKurs);
                            break;
                        case "7":
                            ElevRelaterat.LäggTillElev(connection);
                            break;
                        case "8":
                            Console.WriteLine("Programmet avslutas.");
                            return;
                        default:
                            Console.WriteLine("Ogiltigt val. Försök igen.");
                            Console.WriteLine();
                            break;
                    }
                    Console.WriteLine();
                    Console.WriteLine("Tryck Valfri Knapp För Att Fortsätta");
                    Console.ReadLine();
                }
            }
        }

        public static void ExecuteAndDisplayQuery(SqlConnection connection, string sqlQuery, Action<SqlDataReader> HämtaDatan)
        {
            using (SqlCommand command = new SqlCommand(sqlQuery, connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        HämtaDatan(reader);
                    }
                }
            }
        }



        
        void Huvudmeny()
        {
            Console.WriteLine();
            Console.WriteLine("Välkommen till huvudmenyn!");
            Console.WriteLine("1. Hämta alla elever");
            Console.WriteLine("2. Hämta alla elever i en viss klass");
            Console.WriteLine("3. Lägg till ny personal");
            Console.WriteLine("4. Hämta personal");
            Console.WriteLine("5. Hämta alla betyg från senaste månaden");
            Console.WriteLine("6. Snittbetyg per kurs");
            Console.WriteLine("7. Lägg till nya elever");
            Console.WriteLine("8. Avsluta programmet");
            Console.WriteLine();
            Console.Write("Vänligen välj en funktion genom att mata in en siffra: ");
            Console.WriteLine();
        }
    }
}
